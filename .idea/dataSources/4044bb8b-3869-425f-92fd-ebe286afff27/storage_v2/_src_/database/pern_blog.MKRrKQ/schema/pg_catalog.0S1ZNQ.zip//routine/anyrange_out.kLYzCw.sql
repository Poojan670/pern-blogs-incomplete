create function anyrange_out(anyrange) returns cstring
    language internal
as
$$anyrange_out$$;

comment on function anyrange_out(anyrange) is 'I/O';

