create function bit(integer, integer) returns bit
    language internal
as
$$bitfromint4$$;

comment on function bit(int8, int4) is 'convert int8 to bitstring';

