create function bitor(bit, bit) returns bit
    language internal
as
$$bit_or$$;

comment on function bitor(bit, bit) is 'implementation of | operator';

