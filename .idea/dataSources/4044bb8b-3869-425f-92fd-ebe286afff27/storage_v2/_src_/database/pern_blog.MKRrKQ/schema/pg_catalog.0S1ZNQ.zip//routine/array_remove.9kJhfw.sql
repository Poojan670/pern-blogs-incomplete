create function array_remove(anycompatiblearray, anycompatible) returns anycompatiblearray
    language internal
as
$$array_remove$$;

comment on function array_remove(anycompatiblearray, anycompatible) is 'remove any occurrences of an element from an array';

