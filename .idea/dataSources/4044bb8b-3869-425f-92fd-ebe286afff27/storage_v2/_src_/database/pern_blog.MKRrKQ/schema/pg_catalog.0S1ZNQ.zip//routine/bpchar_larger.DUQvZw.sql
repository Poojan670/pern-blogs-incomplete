create function bpchar_larger(character, character) returns character
    language internal
as
$$bpchar_larger$$;

comment on function bpchar_larger(bpchar, bpchar) is 'larger of two';

