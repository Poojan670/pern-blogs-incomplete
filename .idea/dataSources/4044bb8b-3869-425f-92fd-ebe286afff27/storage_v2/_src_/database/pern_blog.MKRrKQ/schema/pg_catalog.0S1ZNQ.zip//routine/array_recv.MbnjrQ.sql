create function array_recv(internal, oid, integer) returns anyarray
    language internal
as
$$array_recv$$;

comment on function array_recv(internal, oid, int4) is 'I/O';

