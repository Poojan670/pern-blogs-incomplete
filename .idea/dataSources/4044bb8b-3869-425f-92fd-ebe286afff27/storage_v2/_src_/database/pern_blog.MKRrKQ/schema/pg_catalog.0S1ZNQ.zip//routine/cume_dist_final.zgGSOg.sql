create function cume_dist_final(internal, VARIADIC "any") returns double precision
    language internal
as
$$hypothetical_cume_dist_final$$;

comment on function cume_dist_final(internal, any) is 'aggregate final function';

