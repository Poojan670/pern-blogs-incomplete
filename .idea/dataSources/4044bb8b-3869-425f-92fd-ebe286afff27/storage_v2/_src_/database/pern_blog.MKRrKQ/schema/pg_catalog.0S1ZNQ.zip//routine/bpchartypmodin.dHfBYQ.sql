create function bpchartypmodin(cstring[]) returns integer
    language internal
as
$$bpchartypmodin$$;

comment on function bpchartypmodin(_cstring) is 'I/O typmod';

