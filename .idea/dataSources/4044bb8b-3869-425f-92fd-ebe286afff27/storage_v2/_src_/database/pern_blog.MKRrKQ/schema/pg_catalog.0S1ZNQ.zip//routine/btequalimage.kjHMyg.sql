create function btequalimage(oid) returns boolean
    language internal
as
$$btequalimage$$;

comment on function btequalimage(oid) is 'equal image';

