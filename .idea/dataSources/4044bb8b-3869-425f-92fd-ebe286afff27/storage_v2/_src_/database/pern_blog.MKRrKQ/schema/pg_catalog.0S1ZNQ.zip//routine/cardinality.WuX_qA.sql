create function cardinality(anyarray) returns integer
    language internal
as
$$array_cardinality$$;

comment on function cardinality(anyarray) is 'array cardinality';

