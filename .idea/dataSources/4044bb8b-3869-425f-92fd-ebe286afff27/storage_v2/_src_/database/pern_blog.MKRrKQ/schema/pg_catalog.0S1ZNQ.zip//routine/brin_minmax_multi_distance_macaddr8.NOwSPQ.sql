create function brin_minmax_multi_distance_macaddr8(internal, internal) returns double precision
    language internal
as
$$brin_minmax_multi_distance_macaddr8$$;

comment on function brin_minmax_multi_distance_macaddr8(internal, internal) is 'BRIN multi minmax macaddr8 distance';

