create function btint8sortsupport(internal) returns void
    language internal
as
$$btint8sortsupport$$;

comment on function btint8sortsupport(internal) is 'sort support';

