create function byteagt(bytea, bytea) returns boolean
    language internal
as
$$byteagt$$;

comment on function byteagt(bytea, bytea) is 'implementation of > operator';

