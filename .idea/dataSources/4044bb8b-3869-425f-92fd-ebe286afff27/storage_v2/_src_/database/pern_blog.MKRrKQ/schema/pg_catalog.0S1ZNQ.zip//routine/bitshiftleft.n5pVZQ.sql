create function bitshiftleft(bit, integer) returns bit
    language internal
as
$$bitshiftleft$$;

comment on function bitshiftleft(bit, int4) is 'implementation of << operator';

