create function bthandler(internal) returns index_am_handler
    language internal
as
$$bthandler$$;

comment on function bthandler(internal) is 'btree index access method handler';

