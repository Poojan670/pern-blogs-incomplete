create function array_replace(anycompatiblearray, anycompatible, anycompatible) returns anycompatiblearray
    language internal
as
$$array_replace$$;

comment on function array_replace(anycompatiblearray, anycompatible, anycompatible) is 'replace any occurrences of an element in an array';

