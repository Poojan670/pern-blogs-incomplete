create function circle_center(circle) returns point
    language internal
as
$$circle_center$$;

comment on function circle_center(circle) is 'implementation of @@ operator';

