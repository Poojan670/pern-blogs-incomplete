create function "RI_FKey_restrict_del"() returns trigger
    language internal
as
$$RI_FKey_restrict_del$$;

comment on function "RI_FKey_restrict_del"() is 'referential integrity ON DELETE RESTRICT';

