create function cidin(cstring) returns cid
    language internal
as
$$cidin$$;

comment on function cidin(cstring) is 'I/O';

