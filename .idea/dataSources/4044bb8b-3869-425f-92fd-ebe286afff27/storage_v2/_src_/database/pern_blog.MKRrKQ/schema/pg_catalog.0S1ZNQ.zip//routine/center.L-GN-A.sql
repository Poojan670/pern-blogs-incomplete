create function center(box) returns point
    language internal
as
$$box_center$$;

comment on function center(box) is 'center of';

