create function cash_mul_int4(money, integer) returns money
    language internal
as
$$cash_mul_int4$$;

comment on function cash_mul_int4(money, int4) is 'implementation of * operator';

