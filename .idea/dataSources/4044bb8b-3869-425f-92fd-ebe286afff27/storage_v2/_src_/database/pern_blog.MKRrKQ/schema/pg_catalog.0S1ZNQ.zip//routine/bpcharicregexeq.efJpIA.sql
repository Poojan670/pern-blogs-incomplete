create function bpcharicregexeq(character, text) returns boolean
    language internal
as
$$texticregexeq$$;

comment on function bpcharicregexeq(bpchar, text) is 'implementation of ~* operator';

