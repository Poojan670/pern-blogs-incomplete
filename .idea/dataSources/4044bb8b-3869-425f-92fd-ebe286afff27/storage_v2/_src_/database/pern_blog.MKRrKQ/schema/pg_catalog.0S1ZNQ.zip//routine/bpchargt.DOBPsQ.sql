create function bpchargt(character, character) returns boolean
    language internal
as
$$bpchargt$$;

comment on function bpchargt(bpchar, bpchar) is 'implementation of > operator';

